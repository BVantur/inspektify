//
//  MapFrameworkConstants.h
//  UnityFramework
//
//  Created by Andreas Bruns on 08.11.21.
//

#ifndef MapFrameworkConstants_h
#define MapFrameworkConstants_h

static const int MapFrameworkAssetImporterVersion = 3; //unity-xcode-postbuild
static const char *MapFrameworkBuildDate = "2024-11-21"; //unity-xcode-postbuild

#endif /* MapFrameworkConstants_h */
